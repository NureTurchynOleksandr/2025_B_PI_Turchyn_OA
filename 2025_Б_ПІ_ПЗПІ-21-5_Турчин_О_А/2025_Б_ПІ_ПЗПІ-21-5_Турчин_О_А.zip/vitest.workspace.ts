export default ['**/*/vite.config.{ts,mts}', '**/*/vitest.config.{ts,mts}'];
