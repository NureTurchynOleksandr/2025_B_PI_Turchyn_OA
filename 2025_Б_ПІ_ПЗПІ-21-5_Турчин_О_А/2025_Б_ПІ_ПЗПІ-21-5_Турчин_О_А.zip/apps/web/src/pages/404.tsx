export const NoFoundPage = () => {
  return (
    <div>
      <p>404</p>
    </div>
  );
};
