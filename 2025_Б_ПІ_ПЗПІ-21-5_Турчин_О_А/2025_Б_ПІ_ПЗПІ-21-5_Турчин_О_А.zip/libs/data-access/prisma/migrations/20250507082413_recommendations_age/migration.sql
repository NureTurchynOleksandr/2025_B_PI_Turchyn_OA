-- AlterTable
ALTER TABLE "book" ADD COLUMN     "age_restriction" INTEGER DEFAULT 0;

-- AlterTable
ALTER TABLE "user" ADD COLUMN     "age" INTEGER;
