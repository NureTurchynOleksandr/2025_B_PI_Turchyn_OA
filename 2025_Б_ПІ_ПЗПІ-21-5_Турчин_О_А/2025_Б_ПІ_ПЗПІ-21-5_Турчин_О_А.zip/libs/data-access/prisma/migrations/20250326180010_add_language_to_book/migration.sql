-- AlterTable
ALTER TABLE "book" ADD COLUMN     "language" TEXT;
