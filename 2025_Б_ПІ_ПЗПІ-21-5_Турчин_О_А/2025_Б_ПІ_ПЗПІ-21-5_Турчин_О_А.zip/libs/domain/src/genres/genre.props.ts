export interface GenreProps {
  id: string;
  name: string;
}
