export interface TagProps {
  id: string;
  label: string;
}
