export interface BookLikeProps {
  userId: string;
  bookId: string;
  likedAt: Date;
}
