export interface BookFavoriteProps {
  userId: string;
  bookId: string;
  addedAt: Date;
}
