# shared

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build shared` to build the library.
